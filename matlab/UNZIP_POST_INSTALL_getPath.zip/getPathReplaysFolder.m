function replaysFolder = getPathReplaysFolder()
    replaysFolder = 'C:\Users\nikhi\UCB\data-replays\';
end