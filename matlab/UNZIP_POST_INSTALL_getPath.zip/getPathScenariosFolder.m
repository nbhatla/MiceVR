function scenariosFolder = getPathScenariosFolder()
    scenariosFolder = 'C:\Users\nikhi\Documents\GitHub\MiceVR\scenarios\';
end